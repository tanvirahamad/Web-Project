﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace trial
{
    public partial class need_help : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBoxun.Text != "" && TextBoxemail.Text != "" && TextBoxpass.Text != "" && TextBoxcountry.Text !="" )
            {
                if (TextBoxpass.Text == TextBoxconpass.Text)
                {
                    String CS = ConfigurationManager.ConnectionStrings["registrationConnectionString1"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(CS))
                    {
                        SqlCommand cmd = new SqlCommand("insert into TableUserData values('" + TextBoxun.Text + "','" + TextBoxemail.Text + "','" + TextBoxpass.Text + "','" + TextBoxcountry.Text + "')", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                       // lblMsg.ForeColor = Color.Green;
                        //lblMsg.Text = "Regestered Sucessfully!";
                        // Response.Redirect("~/SignIn.aspx");
                        Response.Write("Your registration is Successful");
                    }
                }
                else
                {
                  //  lblMsg.ForeColor = Color.Red;
                  //  lblMsg.Text = "Passwords Do Not Match";
                    Response.Write("Your registration is not Successful");
                }
            }
            else
            {
              //  lblMsg.ForeColor = Color.Red;
               // lblMsg.Text = "All Fields Are Mandatory";
                Response.Write("Your registration is not Successful");
            }
           // Response.Write("Your registration is Successful");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBoxun.Text = "";
            TextBoxemail.Text = "";
            TextBoxpass.Text = "";
            TextBoxconpass.Text = "";
            TextBoxcountry.Text = "";
        }
    }
}