﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (connect.State == ConnectionState.Open)
        {
            connect.Close();
        }
        connect.Open();
        display();
    }
    protected void I_Click(object sender, EventArgs e)
    {

        SqlCommand cmd = connect.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into Info values ('" + F.Text + "','" + L.Text + "','" + M.Text + "')";
       
        cmd.ExecuteNonQuery();

        F.Text = "";
        L.Text = "";
        M.Text = "";

        Response.Write("Sucessful");
        display();
    }
    public void display()
    {
        SqlCommand cmd = connect.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from Info";
        cmd.ExecuteNonQuery();
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }
    protected void D_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = connect.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "delete from Info where F= '"+F.Text+"'";

        cmd.ExecuteNonQuery();

        F.Text = "";
       

        Response.Write("Sucessful");
        display();
    }
    protected void U_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = connect.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "update Info set F = '"+F.Text+"', L = '"+L.Text+"', M = '"+M.Text+"' where Id ="+Convert.ToInt32(id.Text) +" ";

        cmd.ExecuteNonQuery();

        


        Response.Write("Sucessful");
        display();
    }
}