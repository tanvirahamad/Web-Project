﻿CREATE TABLE [dbo].[TableUserData] (
    [Id]       INT            IDENTITY (1, 1) NOT NULL,
    [Username] NVARCHAR (MAX) NULL,
    [Email]    NVARCHAR (MAX) NULL,
    [password] NVARCHAR (MAX) NULL,
    [country]  NVARCHAR (MAX) NULL
);

